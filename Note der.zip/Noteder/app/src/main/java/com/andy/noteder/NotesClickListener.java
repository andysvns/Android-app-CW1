package com.andy.noteder;

import androidx.cardview.widget.CardView;

import com.andy.noteder.Models.Notes;

public interface NotesClickListener {
    void onClick(Notes notes);
    void onLongClick(Notes notes, CardView cardView);
}
